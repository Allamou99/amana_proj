﻿/**
 * YON 31/12/2014
 * Class Email : s'occupe de l'envoi de mail 
 * 
 * */


using System;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading;
using System.ComponentModel;
using System.IO;
using System.Xml.Linq;
using System.Linq;
namespace bamEpplus
{
    public sealed class Email
    {   
        private static bool mailSent = false;
        private static bool mailSentSuccess = false;
        private static String fichier_courant = "";
        private static Email email= new Email();
        // return une instance de Email 
        public static Email getInstance()
        {
                    return email;
        }
        private static bool traitement_mail(String fichier, Parametrage parametrage)
        {
                    SmtpClient client =
                    new SmtpClient
                    {
                        Host = parametrage.Host,
                        Port = parametrage.Port,
                        EnableSsl = parametrage.EnableSsl,
                        UseDefaultCredentials = true,
                        Credentials = new System.Net.NetworkCredential(parametrage.login, parametrage.password),
                        Timeout = 30000
                    };
                    MailAddress from = new MailAddress(parametrage.FROM);
                    // Set destinations for the e-mail message.
                    MailAddress to = new MailAddress(parametrage.TO);
                    // Specify the message content.
                    MailMessage message = new MailMessage(from, to);
                    foreach (String param in parametrage.CC)
                    {

                        message.CC.Add(new MailAddress(param));
                    }

                    message.Body = parametrage.Body;
                    message.Subject = parametrage.Subject;

                    client.SendCompleted += (s, e) =>
                    {
                        SendCompletedCallback(s, e);
                        client.Dispose();
                        message.Dispose();
                    };

                    string userState = parametrage.userState;
                    Attachment attachment = new Attachment(@fichier);
                    message.Attachments.Add(attachment);   
                    client.SendAsync(message, userState);
                    return true;
        }
        private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
                    // Get the unique identifier for this asynchronous operation.
                    String token = (string)e.UserState;

                    if (e.Cancelled)
                    {
                        mailSentSuccess = false;
                        Console.WriteLine("[{0}] Send canceled.", token);
                    }
                    if (e.Error != null)
                    {
                        mailSentSuccess = false;
                        Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
                    }
                    else
                    {
                        mailSentSuccess = true;
                        Console.WriteLine("Email sent.");
                        
                    }
                    mailSent = true;
        }
        public  bool Envoi_mail(Parametrage parametrage)
        {
            var fichiers = Directory.GetFiles(@parametrage.chemin_genration_excel);
            foreach (String fichier in fichiers)
            {
               // Console.WriteLine("Nouveau email .");
                fichier_courant = fichier;
                traitement_mail(fichier, parametrage);
                var mots = fichier_courant.Split('\\');

                String destFile = @parametrage.chemin_archive_excel + @"\" + mots[mots.Length - 1];
                bool resultat = true;
                while (resultat)
                { 
                    if (mailSent)
                    {
                        resultat = false;
                        if (mailSentSuccess)
                        {
                            try
                            {
                                //System.Threading.Thread.Sleep(8000);
                                System.IO.File.Copy(@fichier_courant, @destFile, true);
                                // Console.WriteLine("fichier copy dans:." + destFile);
                                System.Threading.Thread.Sleep(10000);
                                System.IO.File.Delete(@fichier_courant);
                                //Console.WriteLine("fichier supprimer");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("fichier ne peut pas etre supprimé:" + ex.ToString());

                            }
                        }// fin de test que email a été bien envoyé
                    }//fin de test de fin d'envoie d'email
                 }// fin de while

                mailSent = false;
                if (!mailSentSuccess) break;
                mailSentSuccess = false;
            }// fin de foreach 
                   
                return true;
        }// Fin de la methode envoi mail 
    }
}
